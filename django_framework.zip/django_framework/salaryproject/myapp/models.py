from django.db import models
from django.contrib.auth.models import User
from datetime import date

class Employee(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    employee_id = models.CharField(max_length=10, unique=True)
    department = models.CharField(max_length=100)
    position = models.CharField(max_length=100)
    basic_salary = models.DecimalField(max_digits=10, decimal_places=2)
    hire_date = models.DateField()
    phone = models.CharField(max_length=15)
    address = models.TextField()
    
    def __str__(self):
        return f"{self.user.first_name} {self.user.last_name} - {self.employee_id}"

class Salary(models.Model):
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    month = models.IntegerField()
    year = models.IntegerField()
    basic_salary = models.DecimalField(max_digits=10, decimal_places=2)
    allowances = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    overtime = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    deductions = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    tax = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    net_salary = models.DecimalField(max_digits=10, decimal_places=2)
    created_date = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['employee', 'month', 'year']
    
    def save(self, *args, **kwargs):
        self.net_salary = self.basic_salary + self.allowances + self.overtime - self.deductions - self.tax
        super().save(*args, **kwargs)
    
    def __str__(self):
        return f"{self.employee.user.first_name} - {self.month}/{self.year}"