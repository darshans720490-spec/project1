from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('employees/', views.employee_list, name='employee_list'),
    path('employees/<int:employee_id>/', views.employee_detail, name='employee_detail'),
    path('salary/create/', views.create_salary, name='create_salary'),
    path('salary/slip/<int:salary_id>/', views.salary_slip, name='salary_slip'),
    path('login/', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('logout/', views.logout_view, name='logout'),
    path('employees/<int:employee_id>/delete/', views.delete_employee, name='delete_employee'),
]