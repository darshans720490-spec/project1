from django.contrib import admin
from .models import Employee, Salary

@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):
    list_display = ['employee_id', 'get_full_name', 'department', 'position', 'basic_salary', 'hire_date']
    list_filter = ['department', 'position', 'hire_date']
    search_fields = ['employee_id', 'user__first_name', 'user__last_name', 'department']
    
    def get_full_name(self, obj):
        return f"{obj.user.first_name} {obj.user.last_name}"
    get_full_name.short_description = 'Full Name'

@admin.register(Salary)
class SalaryAdmin(admin.ModelAdmin):
    list_display = ['employee', 'month', 'year', 'basic_salary', 'net_salary', 'created_date']
    list_filter = ['month', 'year', 'created_date']
    search_fields = ['employee__user__first_name', 'employee__user__last_name', 'employee__employee_id']
    readonly_fields = ['net_salary', 'created_date']