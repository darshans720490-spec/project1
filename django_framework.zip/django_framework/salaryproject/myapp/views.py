from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from .models import Employee, Salary
from django.contrib.auth.models import User
from datetime import datetime
from django.contrib.auth import authenticate, login, logout
from .forms import CustomUserCreationForm
from decimal import Decimal

def employee_list(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        employee_id = request.POST.get('employee_id')
        department = request.POST.get('department')
        position = request.POST.get('position')
        basic_salary = request.POST.get('basic_salary')
        hire_date = request.POST.get('hire_date')
        phone = request.POST.get('phone')
        address = request.POST.get('address')
        
        user = User.objects.create_user(username=username, first_name=first_name, last_name=last_name, email=email)
        Employee.objects.create(
            user=user,
            employee_id=employee_id,
            department=department,
            position=position,
            basic_salary=basic_salary,
            hire_date=hire_date,
            phone=phone,
            address=address
        )
        messages.success(request, 'Employee added successfully!')
        return redirect('employee_list')
    
    employees = Employee.objects.all()
    return render(request, 'employees/add.html', {'employees': employees})

def employee_detail(request, employee_id):
    employee = get_object_or_404(Employee, id=employee_id)
    salaries = Salary.objects.filter(employee=employee).order_by('-year', '-month')
    return render(request, 'employees/detail.html', {'employee': employee, 'salaries': salaries})

def salary_slip(request, salary_id):
    salary = get_object_or_404(Salary, id=salary_id)
    return render(request, 'salary/slip.html', {'salary': salary})

def create_salary(request):
    if request.method == 'POST':
        employee_id = request.POST.get('employee_id')
        month = int(request.POST.get('month'))
        year = int(request.POST.get('year'))
        allowances = Decimal(request.POST.get('allowances', 0))
        overtime = Decimal(request.POST.get('overtime', 0))
        deductions = Decimal(request.POST.get('deductions', 0))
        tax = Decimal(request.POST.get('tax', 0))
        
        employee = get_object_or_404(Employee, id=employee_id)
        
        salary = Salary.objects.create(
            employee=employee,
            month=month,
            year=year,
            basic_salary=employee.basic_salary,
            allowances=allowances,
            overtime=overtime,
            deductions=deductions,
            tax=tax
        )
        
        messages.success(request, 'Salary created successfully!')
        return redirect('employee_detail', employee_id=employee.id)
    
    employees = Employee.objects.all()
    return render(request, 'salary/create.html', {'employees': employees})

def dashboard(request):
    total_employees = Employee.objects.count()
    current_month = datetime.now().month
    current_year = datetime.now().year
    monthly_salaries = Salary.objects.filter(month=current_month, year=current_year)
    total_payroll = sum(salary.net_salary for salary in monthly_salaries)
    
    context = {
        'total_employees': total_employees,
        'total_payroll': total_payroll,
        'monthly_salaries': monthly_salaries.count(),
        'current_month': current_month,
        'current_year': current_year
    }
    return render(request, 'dashboard.html', context)

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('dashboard')
        messages.error(request, 'Invalid credentials')
    return render(request, 'auth/login.html')

def register_view(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            try:
                user = form.save()
                login(request, user)
                messages.success(request, 'Registration successful!')
                return redirect('dashboard')
            except Exception as e:
                messages.error(request, f'Registration failed: {str(e)}')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f'{field}: {error}')
    else:
        form = CustomUserCreationForm()
    return render(request, 'auth/register.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('login')

def delete_employee(request, employee_id):
    employee = get_object_or_404(Employee, id=employee_id)
    employee.delete()
    messages.success(request, f'Employee {employee.user.first_name} {employee.user.last_name} deleted successfully!')
    return redirect('employee_list')