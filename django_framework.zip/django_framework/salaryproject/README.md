# Employee Salary Management System

A Django-based web application for managing employee salaries and generating salary slips.

## Features

- **Employee Management**: View and manage employee information
- **Salary Processing**: Create and manage monthly salaries
- **Salary Slips**: Generate professional salary slips with print functionality
- **Dashboard**: Overview of payroll statistics
- **Admin Interface**: Full CRUD operations for employees and salaries

## Technologies Used

- **Backend**: Python, Django 5.2.7
- **Database**: SQLite (default)
- **Frontend**: HTML5, CSS3, JavaScript
- **Styling**: Custom CSS with responsive design

## Installation & Setup

1. **Navigate to project directory**:
   ```bash
   cd salaryproject
   ```

2. **Install dependencies** (if using virtual environment):
   ```bash
   pip install django
   ```

3. **Run migrations** (already done):
   ```bash
   python manage.py migrate
   ```

4. **Start the development server**:
   ```bash
   python manage.py runserver
   ```

5. **Access the application**:
   - Main application: http://127.0.0.1:8000/
   - Admin panel: http://127.0.0.1:8000/admin/

## Default Login Credentials

- **Admin User**: 
  - Username: `admin`
  - Password: `admin123`

## Sample Data

The system comes with 3 sample employees:
- John Doe (EMP001) - IT Department
- Jane Smith (EMP002) - HR Department  
- Mike Johnson (EMP003) - Finance Department

Each employee has salary records for the last 3 months (Oct, Nov, Dec 2024).

## Usage

### Dashboard
- View total employees, monthly payroll, and processed salaries
- Quick access to main features

### Employee Management
- View all employees with their basic information
- Click on any employee to see detailed information and salary history

### Salary Processing
1. Go to "Create Salary" from the navigation
2. Select employee, month, and year
3. Enter allowances, overtime, deductions, and tax
4. System automatically calculates net salary

### Salary Slips
- Access from employee detail page
- Professional format with company letterhead
- Print-ready design
- Shows detailed breakdown of earnings and deductions

## Database Models

### Employee Model
- Links to Django User model
- Employee ID, department, position
- Basic salary, hire date, contact info

### Salary Model
- Links to Employee
- Monthly salary components
- Auto-calculates net salary
- Unique constraint per employee per month/year

## File Structure

```
salaryproject/
├── myapp/
│   ├── templates/
│   │   ├── base.html
│   │   ├── dashboard.html
│   │   ├── employees/
│   │   │   ├── list.html
│   │   │   └── detail.html
│   │   └── salary/
│   │       ├── create.html
│   │       └── slip.html
│   ├── models.py
│   ├── views.py
│   ├── urls.py
│   └── admin.py
├── static/
├── manage.py
└── create_sample_data.py
```

## Customization

- Modify CSS in `base.html` for styling changes
- Update company information in salary slip template
- Add more fields to Employee/Salary models as needed
- Implement user authentication for employee self-service

## Future Enhancements

- Employee self-service portal
- Email salary slips
- Advanced reporting and analytics
- Integration with payroll systems
- Multi-company support