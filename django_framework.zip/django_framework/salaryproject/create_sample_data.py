import os
import django
from datetime import date
from decimal import Decimal

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'salaryproject.settings')
django.setup()

from django.contrib.auth.models import User
from myapp.models import Employee, Salary

# Create sample users and employees
def create_sample_data():
    # Create sample employees
    users_data = [
        {'username': 'john_doe', 'first_name': 'John', 'last_name': 'Doe', 'email': 'john@company.com'},
        {'username': 'jane_smith', 'first_name': 'Jane', 'last_name': 'Smith', 'email': 'jane@company.com'},
        {'username': 'mike_johnson', 'first_name': 'Mike', 'last_name': 'Johnson', 'email': 'mike@company.com'},
    ]
    
    employees_data = [
        {'employee_id': 'EMP001', 'department': 'IT', 'position': 'Software Developer', 'basic_salary': 5000, 'phone': '123-456-7890', 'address': '123 Main St'},
        {'employee_id': 'EMP002', 'department': 'HR', 'position': 'HR Manager', 'basic_salary': 6000, 'phone': '123-456-7891', 'address': '456 Oak Ave'},
        {'employee_id': 'EMP003', 'department': 'Finance', 'position': 'Accountant', 'basic_salary': 4500, 'phone': '123-456-7892', 'address': '789 Pine Rd'},
    ]
    
    for i, user_data in enumerate(users_data):
        user, created = User.objects.get_or_create(
            username=user_data['username'],
            defaults=user_data
        )
        
        if created:
            user.set_password('password123')
            user.save()
            
            employee_data = employees_data[i]
            employee_data['user'] = user
            employee_data['hire_date'] = date(2023, 1, 15)
            
            Employee.objects.get_or_create(
                employee_id=employee_data['employee_id'],
                defaults=employee_data
            )
            print(f"Created employee: {user.first_name} {user.last_name}")
    
    # Create sample salary records
    employees = Employee.objects.all()
    for employee in employees:
        for month in [10, 11, 12]:  # Last 3 months
            salary, created = Salary.objects.get_or_create(
                employee=employee,
                month=month,
                year=2024,
                defaults={
                    'basic_salary': employee.basic_salary,
                    'allowances': 500,
                    'overtime': 200,
                    'deductions': 100,
                    'tax': employee.basic_salary * Decimal('0.1'),
                }
            )
            if created:
                print(f"Created salary for {employee.user.first_name} - {month}/2024")

if __name__ == '__main__':
    create_sample_data()
    print("Sample data created successfully!")